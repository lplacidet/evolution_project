# GRGEN

These files are a snapshot of files found in the GRN library
[GRGEN](https://github.com/jdisset/grgen)
